# treehouse_unit3_project
//Ryan Emslie submission of Project 3
//I am attempting the "Exceeds Expectation"
//Extra Credit for T-shirt, Line 49
//Extra Credit - Conditional Error, Line 178
//Extra Credit - Real Time Error, Line 22
