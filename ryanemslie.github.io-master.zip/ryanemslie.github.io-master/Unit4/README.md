# treehouse_unit_4_project_exceeds
//Ryan Emslie - JavaScript Full Stack
//Techdegree - Unit 4 - Exceeds Expectation
//This version of the program is set up to be a human verse computer player
//One issue I ran into was that the computer 'plays' too quickly for the blue 'active' class to be visible
//I did not use the minmax algorithm, instead I wanted to porgram with the knowledge I had
//I designed this so it wasn't a 'perfect game' - meaning a tie everytime - the computer is beatable
//Still feel like I am still not achieving "D.R.Y." programming but getting better